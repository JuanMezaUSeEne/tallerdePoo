public class d{
    public static void main(String[] args){
        String a = "1";
        System.out.print(a.length());
    }
}